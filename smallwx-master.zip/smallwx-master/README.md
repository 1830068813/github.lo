 ## 二手书交易平台微信小程序
##效果图如下：
 ![image](https://github.com/mindasiy/smallwx/raw/master/images-folder/psd.jpg)
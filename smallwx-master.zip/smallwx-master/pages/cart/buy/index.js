Page({
open() {
        wx.redirectTo({url:"/pages/usp/index"})  
    },	
})
//app.js
Page({
  data:{
  	arrayLesson:['课内', '课外'],
  	arrayCat:['分类',"分类"],
	index:0
  }
})
Page({
	data:{
		arr:["男","女"],
		index:0
	}
})
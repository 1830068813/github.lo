Page({
	data:{
		arr:["南京","常州"],
		index:0
	}
})